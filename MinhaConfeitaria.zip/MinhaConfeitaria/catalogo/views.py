from django.shortcuts import render

from django.shortcuts import render, redirect
from django.http import HttpResponse

from .forms import BoloForm
from .models import Bolo

# Create your views here.

def pagina_inicial(request):
    return render(request, 'catalogo/index.html')

def lista_bolos(request):
    bolos = Bolo.objects.all()

    return render(request, 'catalogo/bolos.html', {'bolos': bolos})

def novo_bolo(request):
    if request.method != 'POST':
        form = BoloForm()

        return render(request, 'catalogo/nova_bolo.html', {'form': form})
    else:
        form = BoloForm(request.POST)

        if form.is_valid():
            return redirect('catalogo:lista_bolos')
        return None