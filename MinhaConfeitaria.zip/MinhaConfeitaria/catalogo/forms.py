from django import forms
from .models import Bolo

class BoloForm(forms.ModelForm):
    class Meta:
        #Em qual modelo o form sera criado
        model = Bolo

        #Quais campos serao exibidos no forms
        fields = ['nome', 'sabor', 'descricao', 'preco', 'disponivel']